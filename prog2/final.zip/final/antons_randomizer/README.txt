A Pen created at CodePen.io. You can find this one at http://codepen.io/garyyo/pen/mAdjVG.

 an implementation of the kaos/atomic chaos puzzle, a novel way to get a state close to solution, and ultimately a conclusion